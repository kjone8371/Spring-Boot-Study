package org.example.spring_study.service;

public interface GreetingService {

    public String sayHello(String name);

    public String sayGoodbye();

}
