package org.example.spring_study.service;

public interface CounterService {

    public int increase();

}
